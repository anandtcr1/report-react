using Microsoft.AspNetCore.Mvc;
using QuestPDF.Fluent;

namespace ReportDataApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpGet("sales")]
        public IActionResult GetSalesReport()
        {
            // Get data (from DB or service)
            var data = new List<SalesData>
        {
            new() { Product = "Laptop", Quantity = 10, Price = 999.99m },
            new() { Product = "Mouse", Quantity = 50, Price = 29.99m },
            new() { Product = "Keyboard", Quantity = 30, Price = 79.99m }
        };

            var document = new SalesReportDocument(data);
            byte[] pdfBytes = document.GeneratePdf();

            return File(pdfBytes, "application/pdf", "SalesReport.pdf");
        }
    }
}
