﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ReportDataApi.Controllers
{
    public class SalesReportDocument : IDocument
    {
        public List<SalesData> Data { get; set; }

        public SalesReportDocument(List<SalesData> data)
        {
            Data = data;
        }

        public DocumentMetadata GetMetadata() => DocumentMetadata.Default;

        public void Compose(IDocumentContainer container)
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(30);

                // Header
                page.Header().Text("Sales Report")
                    .FontSize(20).Bold().AlignCenter();

                // Content
                page.Content().PaddingVertical(10).Table(table =>
                {
                    // Define columns
                    table.ColumnsDefinition(columns =>
                    {
                        columns.RelativeColumn(3); // Product
                        columns.RelativeColumn(2); // Quantity
                        columns.RelativeColumn(2); // Price
                        columns.RelativeColumn(2); // Total
                    });

                    // Table Header
                    table.Header(header =>
                    {
                        header.Cell().Background(Colors.Grey.Lighten2).Padding(5)
                            .Text("Product").Bold();
                        header.Cell().Background(Colors.Grey.Lighten2).Padding(5)
                            .Text("Quantity").Bold();
                        header.Cell().Background(Colors.Grey.Lighten2).Padding(5)
                            .Text("Price").Bold();
                        header.Cell().Background(Colors.Grey.Lighten2).Padding(5)
                            .Text("Total").Bold();
                    });

                    // Table Rows
                    foreach (var item in Data)
                    {
                        table.Cell().Padding(5).Text(item.Product);
                        table.Cell().Padding(5).Text(item.Quantity.ToString());
                        table.Cell().Padding(5).Text($"${item.Price:F2}");
                        table.Cell().Padding(5).Text($"${item.Total:F2}");
                    }
                });

                // Footer
                page.Footer().AlignCenter().Text(text =>
                {
                    text.Span("Page ");
                    text.CurrentPageNumber();
                    text.Span(" of ");
                    text.TotalPages();
                });
            });
        }
    }

    public class SalesData
    {
        public string Product { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal Total => Quantity * Price;
    }
}
